#!/usr/bin/env bash
# Builds build/libs/dronemod-1.0.0.jar. Needs JDK 17 and internet. No Gradle install needed.
set -e
cd "$(dirname "$0")"
V=$(java -version 2>&1 | head -1 | sed -E 's/.*"([0-9]+).*/\1/')
if [ "$V" != "17" ]; then echo "WARNING: Java $V found - ForgeGradle 6 needs JDK 17 (set JAVA_HOME to a JDK 17)."; fi
if command -v gradle >/dev/null 2>&1 && gradle --version 2>/dev/null | grep -q "Gradle 8"; then G=gradle; else
  if [ ! -d .gradle-dist/gradle-8.1.1 ]; then
    mkdir -p .gradle-dist
    echo "Downloading Gradle 8.1.1..."
    curl -L -o .gradle-dist/gradle.zip https://services.gradle.org/distributions/gradle-8.1.1-bin.zip
    unzip -q .gradle-dist/gradle.zip -d .gradle-dist
  fi
  G=.gradle-dist/gradle-8.1.1/bin/gradle
fi
$G build
echo; echo "DONE -> build/libs/"; ls build/libs
