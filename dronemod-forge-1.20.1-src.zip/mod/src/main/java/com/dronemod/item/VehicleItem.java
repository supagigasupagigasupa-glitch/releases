package com.dronemod.item;

import com.dronemod.entity.VehicleEntity;
import com.dronemod.entity.VehicleType;
import com.dronemod.registry.ModEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;

/** places a vehicle in the world */
public class VehicleItem extends Item {
    private final VehicleType type;

    public VehicleItem(Properties props, VehicleType type) {
        super(props);
        this.type = type;
    }

    @Override
    public InteractionResult useOn(UseOnContext ctx) {
        Level level = ctx.getLevel();
        if (level.isClientSide) return InteractionResult.SUCCESS;
        BlockPos pos = ctx.getClickedPos().relative(ctx.getClickedFace());
        VehicleEntity e = ModEntities.get(type).create(level);
        if (e == null) return InteractionResult.FAIL;
        e.moveTo(pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5, ctx.getRotation(), 0f);
        level.addFreshEntity(e);
        Player p = ctx.getPlayer();
        if (p == null || !p.getAbilities().instabuild) ctx.getItemInHand().shrink(1);
        level.playSound(null, pos, SoundEvents.IRON_TRAPDOOR_OPEN, SoundSource.NEUTRAL, 1.0f, 1.3f);
        return InteractionResult.CONSUME;
    }
}
