package com.dronemod.item;

import com.dronemod.control.ControlManager;
import com.dronemod.entity.VehicleEntity;
import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

/**
 * Right-click a vehicle: get in. Sneak + right-click: pilot it remotely through its camera.
 * Right-click in the air while piloting remotely: disconnect.
 */
public class RemoteItem extends Item {
    public RemoteItem(Properties props) { super(props); }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (!level.isClientSide && player instanceof ServerPlayer sp && ControlManager.REMOTE.containsKey(sp.getUUID())) {
            VehicleEntity v = ControlManager.vehicleOf(sp);
            if (v != null) v.stopRemote(sp);
        }
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("tooltip.dronemod.remote.1"));
        tooltip.add(Component.translatable("tooltip.dronemod.remote.2"));
    }
}
