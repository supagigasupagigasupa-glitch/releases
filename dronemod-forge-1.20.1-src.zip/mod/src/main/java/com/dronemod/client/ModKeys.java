package com.dronemod.client;

import net.minecraft.client.KeyMapping;
import org.lwjgl.glfw.GLFW;

public class ModKeys {
    public static final String CATEGORY = "key.categories.dronemod";
    public static final KeyMapping TRANSFORM = new KeyMapping("key.dronemod.transform", GLFW.GLFW_KEY_R, CATEGORY);
    public static final KeyMapping DESCEND = new KeyMapping("key.dronemod.descend", GLFW.GLFW_KEY_LEFT_CONTROL, CATEGORY);
    public static final KeyMapping SMASH = new KeyMapping("key.dronemod.smash", GLFW.GLFW_KEY_V, CATEGORY);
    public static final KeyMapping EXIT_REMOTE = new KeyMapping("key.dronemod.exit_remote", GLFW.GLFW_KEY_X, CATEGORY);
}
