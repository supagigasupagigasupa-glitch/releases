package com.dronemod.client.render;

import com.dronemod.DroneMod;
import com.dronemod.entity.VehicleEntity;
import net.minecraft.resources.ResourceLocation;
import software.bernie.geckolib.model.GeoModel;

/** several vehicles share one model, e.g. the mini and giant transformers */
public class VehicleModel extends GeoModel<VehicleEntity> {
    @Override
    public ResourceLocation getModelResource(VehicleEntity e) {
        return new ResourceLocation(DroneMod.MODID, "geo/" + e.getVehicleType().model + ".geo.json");
    }

    @Override
    public ResourceLocation getTextureResource(VehicleEntity e) {
        return new ResourceLocation(DroneMod.MODID, "textures/entity/" + e.getVehicleType().model + ".png");
    }

    @Override
    public ResourceLocation getAnimationResource(VehicleEntity e) {
        return new ResourceLocation(DroneMod.MODID, "animations/" + e.getVehicleType().model + ".animation.json");
    }
}
