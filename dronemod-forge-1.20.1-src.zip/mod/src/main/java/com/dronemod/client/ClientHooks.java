package com.dronemod.client;

import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.Entity;

/** entry points used by the network packets (kept separate so the server never loads client classes) */
public class ClientHooks {
    public static void remoteMode(boolean start, int entityId) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null) return;
        if (start) {
            ClientState.pendingRemote = entityId;
            applyPending(mc);
        } else {
            ClientState.remote = false;
            ClientState.remoteId = -1;
            ClientState.pendingRemote = -1;
            if (!FusionClient.active()) mc.setCameraEntity(mc.player);
        }
    }

    /** called every tick: the entity may not be known to the client right when the packet arrives */
    public static void applyPending(Minecraft mc) {
        if (ClientState.pendingRemote < 0 || mc.level == null || mc.player == null) return;
        Entity e = mc.level.getEntity(ClientState.pendingRemote);
        if (e == null) return;
        ClientState.remote = true;
        ClientState.remoteId = ClientState.pendingRemote;
        ClientState.pendingRemote = -1;
        mc.setCameraEntity(e);
        mc.player.displayClientMessage(Component.translatable("message.dronemod.remote_on", ModKeys.EXIT_REMOTE.getTranslatedKeyMessage()), true);
    }

    public static void fusion(double x, double y, double z, double theta0) {
        FusionClient.start(x, y, z, theta0);
    }
}
