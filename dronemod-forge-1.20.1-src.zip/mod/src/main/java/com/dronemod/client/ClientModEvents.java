package com.dronemod.client;

import com.dronemod.DroneMod;
import com.dronemod.client.render.VehicleRenderer;
import com.dronemod.client.screen.ComputerScreen;
import com.dronemod.entity.VehicleType;
import com.dronemod.registry.ModEntities;
import com.dronemod.registry.ModMenus;
import net.minecraft.client.gui.screens.MenuScreens;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.client.event.RegisterGuiOverlaysEvent;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;

@Mod.EventBusSubscriber(modid = DroneMod.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class ClientModEvents {
    @SubscribeEvent
    public static void registerRenderers(EntityRenderersEvent.RegisterRenderers e) {
        for (VehicleType vt : VehicleType.values()) {
            e.registerEntityRenderer(ModEntities.get(vt), ctx -> new VehicleRenderer(ctx, vt));
        }
    }

    @SubscribeEvent
    public static void registerKeys(RegisterKeyMappingsEvent e) {
        e.register(ModKeys.TRANSFORM);
        e.register(ModKeys.DESCEND);
        e.register(ModKeys.SMASH);
        e.register(ModKeys.EXIT_REMOTE);
    }

    @SubscribeEvent
    public static void registerOverlays(RegisterGuiOverlaysEvent e) {
        e.registerAboveAll("pilot_hud", PilotHud::render);
        e.registerAboveAll("fusion_cinematic", FusionClient::renderOverlay);
    }

    @SubscribeEvent
    public static void clientSetup(FMLClientSetupEvent e) {
        e.enqueueWork(() -> MenuScreens.register(ModMenus.COMPUTER.get(), ComputerScreen::new));
    }
}
