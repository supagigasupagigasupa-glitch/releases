package com.dronemod.client;

import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.CameraType;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.client.gui.overlay.ForgeGui;

/**
 * Client side of the fusion cutscene (100 ticks = 5 s): an invisible camera entity orbits the two mechas,
 * pushes in, flashes white and pulls back to reveal the Fusion Titan. Input and the vanilla HUD are suppressed meanwhile.
 */
public class FusionClient {
    private static final int DURATION = 100;
    private static int t = -1;
    private static Vec3 mid = Vec3.ZERO;
    private static double theta0;
    private static ArmorStand cam;
    private static CameraType prevType = CameraType.FIRST_PERSON;

    public static boolean active() { return t >= 0; }

    private static double ease(double x) { x = Mth.clamp(x, 0, 1); return x * x * (3 - 2 * x); }
    private static double lerp(double a, double b, double k) { return a + (b - a) * k; }

    public static void start(double x, double y, double z, double th) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null) return;
        mid = new Vec3(x, y, z);
        theta0 = th;
        t = 0;
        cam = new ArmorStand(EntityType.ARMOR_STAND, mc.level);
        cam.setInvisible(true);
        cam.setNoGravity(true);
        prevType = mc.options.getCameraType();
        mc.options.setCameraType(CameraType.FIRST_PERSON);
        mc.setCameraEntity(cam);
        update(mc, true);
    }

    public static void tick() {
        Minecraft mc = Minecraft.getInstance();
        if (t < 0) return;
        if (mc.level == null || mc.player == null) { t = -1; return; }
        t++;
        update(mc, false);
        if (t >= DURATION) end(mc);
    }

    private static void end(Minecraft mc) {
        t = -1;
        cam = null;
        mc.setCameraEntity(mc.player);
        mc.options.setCameraType(prevType);
    }

    /** camera position + focus point for tick {@code k} - the same timeline the server uses to move the mechas */
    private static double[] pose(int k) {
        double rise = k < 80 ? 5 * ease(k / 50.0) + Math.sin(k * 0.35) * 0.25 : 0;
        double fx = mid.x, fy = k < 80 ? mid.y + rise + 2 : mid.y + 3.5, fz = mid.z;
        double theta, r, h;
        if (k < 40) { double u = ease(k / 40.0); theta = theta0 + 2.1 * u; r = lerp(16, 11, u); h = lerp(3, 4.5, u); }
        else if (k < 72) { double u = ease((k - 40) / 32.0); theta = theta0 + 2.1 + 2.4 * u; r = lerp(11, 5, u); h = lerp(4.5, 2, u); }
        else if (k < 80) { double u = ease((k - 72) / 8.0); theta = theta0 + 4.5 + 0.4 * u; r = lerp(5, 2.5, u); h = lerp(2, 1.5, u); }
        else { double u = ease((k - 80) / 20.0); theta = theta0 + 4.9 + 0.7 * u; r = lerp(3, 17, u); h = lerp(0.5, 6, u); }
        return new double[] { fx + Math.cos(theta) * r, fy + h - 1, fz + Math.sin(theta) * r, fx, fy, fz };
    }

    private static void update(Minecraft mc, boolean snap) {
        if (cam == null) return;
        double[] p = pose(t);
        double dx = p[3] - p[0], dy = p[4] - p[1], dz = p[5] - p[2];
        float yaw = (float) (Mth.atan2(dz, dx) * 57.29578F) - 90.0F;
        float pitch = (float) -(Mth.atan2(dy, Math.sqrt(dx * dx + dz * dz)) * 57.29578F);
        double y = p[1] - cam.getEyeHeight();
        if (snap) { cam.xo = p[0]; cam.yo = y; cam.zo = p[2]; cam.xOld = p[0]; cam.yOld = y; cam.zOld = p[2]; cam.yRotO = yaw; cam.xRotO = pitch; }
        else { cam.xo = cam.getX(); cam.yo = cam.getY(); cam.zo = cam.getZ(); cam.xOld = cam.xo; cam.yOld = cam.yo; cam.zOld = cam.zo; cam.yRotO = cam.getYRot(); cam.xRotO = cam.getXRot(); }
        cam.setPos(p[0], y, p[2]);
        cam.setYRot(yaw);
        cam.setXRot(pitch);
        cam.yHeadRot = yaw;
        cam.yHeadRotO = yaw;
        cam.yBodyRot = yaw;
        cam.yBodyRotO = yaw;
    }

    /** field of view: a slow zoom in, a wide-angle punch at the flash, then back to normal */
    public static double fov(double base) {
        if (t < 5) return base;
        if (t < 66) return lerp(base, 70, ease((t - 5) / 10.0));
        if (t < 80) return lerp(70, 100, ease((t - 66) / 8.0));
        return lerp(100, base, ease((t - 80) / 15.0));
    }

    /** letterbox bars, white flash and the title cards */
    public static void renderOverlay(ForgeGui gui, GuiGraphics g, float partialTick, int w, int h) {
        if (t < 0) return;
        double barIn = ease(t / 10.0), barOut = t > DURATION - 8 ? ease((DURATION - t) / 8.0) : 1.0;
        int bar = (int) (h * 0.12 * barIn * barOut);
        g.fill(0, 0, w, bar, 0xFF000000);
        g.fill(0, h - bar, w, h, 0xFF000000);

        double flash = 0;
        if (t >= 72 && t < 76) flash = (t - 72 + partialTick) / 4.0;
        else if (t >= 76 && t < 80) flash = 1;
        else if (t >= 80 && t < 92) flash = 1 - (t - 80 + partialTick) / 12.0;
        if (flash > 0) {
            int a = (int) (Mth.clamp(flash, 0, 1) * 255);
            g.fill(0, 0, w, h, (a << 24) | 0xFFFFFF);
        }

        Component title = null;
        if (t >= 45 && t < 70) title = Component.translatable("gui.dronemod.fusion.title");
        else if (t >= 82) title = Component.translatable("gui.dronemod.fusion.done");
        if (title != null) {
            PoseStack ps = g.pose();
            ps.pushPose();
            ps.translate(w / 2f, h * 0.2f, 0);
            ps.scale(3f, 3f, 1f);
            g.drawCenteredString(Minecraft.getInstance().font, title, 0, 0, t >= 82 ? 0xFFECBE46 : 0xFFFFFFFF);
            ps.popPose();
        }
    }
}
