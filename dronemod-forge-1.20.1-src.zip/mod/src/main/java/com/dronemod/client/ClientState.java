package com.dronemod.client;

import com.dronemod.entity.VehicleEntity;
import javax.annotation.Nullable;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.Entity;

/** client-side flags: are we remote piloting, and which vehicle are we in control of */
public class ClientState {
    public static boolean remote = false;
    public static int remoteId = -1;
    /** entity id waiting to become available on the client */
    public static int pendingRemote = -1;

    @Nullable
    public static VehicleEntity currentVehicle(Minecraft mc) {
        if (mc.player == null || mc.level == null) return null;
        if (mc.player.getVehicle() instanceof VehicleEntity v) return v;
        if (remote) {
            Entity e = mc.level.getEntity(remoteId);
            if (e instanceof VehicleEntity v) return v;
        }
        return null;
    }

    public static void reset() {
        remote = false;
        remoteId = -1;
        pendingRemote = -1;
    }
}
