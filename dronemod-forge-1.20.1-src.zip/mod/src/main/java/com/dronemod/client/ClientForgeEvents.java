package com.dronemod.client;

import com.dronemod.DroneMod;
import com.dronemod.client.screen.RadialMenuScreen;
import com.dronemod.control.ControlState;
import com.dronemod.entity.VehicleEntity;
import com.dronemod.network.ActionPacket;
import com.dronemod.network.ControlPacket;
import com.dronemod.network.ModNetwork;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.Input;
import net.minecraft.client.player.LocalPlayer;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.MovementInputUpdateEvent;
import net.minecraftforge.client.event.RenderGuiOverlayEvent;
import net.minecraftforge.client.event.RenderHandEvent;
import net.minecraftforge.client.event.ViewportEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = DroneMod.MODID, value = Dist.CLIENT)
public class ClientForgeEvents {

    private static void drainKeys() {
        while (ModKeys.TRANSFORM.consumeClick()) { }
        while (ModKeys.SMASH.consumeClick()) { }
        while (ModKeys.EXIT_REMOTE.consumeClick()) { }
    }

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer p = mc.player;
        if (p == null || mc.level == null) { ClientState.reset(); return; }

        if (FusionClient.active()) { FusionClient.tick(); drainKeys(); return; }
        ClientHooks.applyPending(mc);

        VehicleEntity v = ClientState.currentVehicle(mc);
        if (ClientState.remote && v == null) { ClientHooks.remoteMode(false, 0); drainKeys(); return; }
        if (v == null) { drainKeys(); return; }

        if (mc.screen == null) {
            ControlState s = new ControlState();
            s.forward = (mc.options.keyUp.isDown() ? 1 : 0) - (mc.options.keyDown.isDown() ? 1 : 0);
            s.strafe = (mc.options.keyLeft.isDown() ? 1 : 0) - (mc.options.keyRight.isDown() ? 1 : 0);
            s.up = mc.options.keyJump.isDown();
            s.down = ModKeys.DESCEND.isDown();
            s.boost = mc.options.keySprint.isDown();
            s.yaw = p.getYRot();
            s.pitch = p.getXRot();
            ModNetwork.CH.sendToServer(new ControlPacket(s));

            while (ModKeys.TRANSFORM.consumeClick()) {
                if (!v.getVehicleType().transformable) continue;
                if (v.getVehicleType().multiForm()) mc.setScreen(new RadialMenuScreen(v));
                else ModNetwork.CH.sendToServer(new ActionPacket(ActionPacket.TOGGLE, 0));
            }
            while (ModKeys.SMASH.consumeClick()) ModNetwork.CH.sendToServer(new ActionPacket(ActionPacket.SMASH, 0));
            while (ModKeys.EXIT_REMOTE.consumeClick()) {
                if (ClientState.remote) ModNetwork.CH.sendToServer(new ActionPacket(ActionPacket.EXIT_REMOTE, 0));
            }
        } else {
            drainKeys();
        }
    }

    /** while remote piloting (or in the cutscene) the player's own body must not walk around */
    @SubscribeEvent
    public static void onMovementInput(MovementInputUpdateEvent e) {
        if (!ClientState.remote && !FusionClient.active()) return;
        Input in = e.getInput();
        in.leftImpulse = 0;
        in.forwardImpulse = 0;
        in.jumping = false;
        in.shiftKeyDown = false;
        in.up = false;
        in.down = false;
        in.left = false;
        in.right = false;
    }

    @SubscribeEvent
    public static void onRenderHand(RenderHandEvent e) {
        if (ClientState.remote || FusionClient.active()) e.setCanceled(true);
    }

    @SubscribeEvent
    public static void onFov(ViewportEvent.ComputeFov e) {
        if (FusionClient.active()) e.setFOV(FusionClient.fov(e.getFOV()));
    }

    @SubscribeEvent
    public static void onOverlay(RenderGuiOverlayEvent.Pre e) {
        if (FusionClient.active() && e.getOverlay().id().getNamespace().equals("minecraft")) e.setCanceled(true);
    }
}
