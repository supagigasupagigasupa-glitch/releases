package com.dronemod.fusion;

import com.dronemod.DroneMod;
import com.dronemod.entity.VehicleEntity;
import com.dronemod.entity.VehicleType;
import com.dronemod.network.FusionPacket;
import com.dronemod.network.ModNetwork;
import com.dronemod.registry.ModEntities;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.network.PacketDistributor;

/**
 * Server side of the 5 second fusion: the two mechas rise, spin and pull together, flash, and are replaced by the Fusion Titan.
 * The matching camera work is done on the client by {@code FusionClient} (same timeline, 100 ticks).
 */
@Mod.EventBusSubscriber(modid = DroneMod.MODID)
public class FusionManager {
    public static final int DURATION = 100;
    private static final Map<UUID, Session> SESSIONS = new HashMap<>();

    private static class Session {
        final ServerPlayer player;
        final ServerLevel level;
        final VehicleEntity a, b;
        final Vec3 a0, b0, mid;
        int t = 0;

        Session(ServerPlayer player, ServerLevel level, VehicleEntity a, VehicleEntity b) {
            this.player = player; this.level = level; this.a = a; this.b = b;
            this.a0 = a.position(); this.b0 = b.position();
            this.mid = new Vec3((a0.x + b0.x) / 2, Math.min(a0.y, b0.y), (a0.z + b0.z) / 2);
        }
    }

    private static double ease(double x) { x = Math.max(0, Math.min(1, x)); return x * x * (3 - 2 * x); }
    private static double lerp(double a, double b, double t) { return a + (b - a) * t; }

    /** @return true when a fusion was started */
    public static boolean start(ServerPlayer player) {
        if (SESSIONS.containsKey(player.getUUID())) return false;
        ServerLevel level = player.serverLevel();
        List<VehicleEntity> cand = new ArrayList<>(level.getEntitiesOfClass(VehicleEntity.class, player.getBoundingBox().inflate(24),
                v -> v.getVehicleType().transformable && v.isAlive() && v.getPassengers().isEmpty() && !v.isRemoteControlled() && !v.isTransitioning()));
        cand.sort(Comparator.comparingDouble(v -> v.distanceToSqr(player)));
        if (cand.size() < 2) {
            player.displayClientMessage(Component.translatable("message.dronemod.fusion_need_two"), true);
            return false;
        }
        VehicleEntity a = cand.get(0), b = cand.get(1);
        if (a.distanceTo(b) > 26) {
            player.displayClientMessage(Component.translatable("message.dronemod.fusion_too_far"), true);
            return false;
        }
        Session s = new Session(player, level, a, b);
        SESSIONS.put(player.getUUID(), s);
        double theta0 = Math.atan2(player.getZ() - s.mid.z, player.getX() - s.mid.x);
        ModNetwork.CH.send(PacketDistributor.PLAYER.with(() -> player), new FusionPacket(s.mid.x, s.mid.y, s.mid.z, theta0));
        level.playSound(null, player.blockPosition(), SoundEvents.BEACON_ACTIVATE, SoundSource.PLAYERS, 1.5f, 0.8f);
        return true;
    }

    @SubscribeEvent
    public static void onTick(TickEvent.ServerTickEvent e) {
        if (e.phase != TickEvent.Phase.END || SESSIONS.isEmpty()) return;
        Iterator<Session> it = SESSIONS.values().iterator();
        while (it.hasNext()) {
            Session s = it.next();
            if (!tick(s)) it.remove();
        }
    }

    private static void place(VehicleEntity e, double x, double y, double z, float yaw) {
        e.setNoGravity(true);
        e.setDeltaMovement(Vec3.ZERO);
        e.moveTo(x, y, z, yaw, 0f);
        e.yBodyRot = yaw;
        e.yHeadRot = yaw;
        e.hurtMarked = true;
    }

    private static boolean tick(Session s) {
        if (s.player.isRemoved() || !s.player.isAlive()) return false;
        int t = s.t++;
        ServerLevel lvl = s.level;
        Vec3 mid = s.mid;
        if (t < 80) {
            if (s.a.isRemoved() || s.b.isRemoved()) return false;
            double e = ease(t / 70.0);
            double rise = 5 * ease(t / 50.0) + Math.sin(t * 0.35) * 0.25;
            double dx = s.b0.x - s.a0.x, dz = s.b0.z - s.a0.z;
            double len = Math.hypot(dx, dz);
            double ux = 1, uz = 0;
            if (len > 0.01) { ux = dx / len; uz = dz / len; } else len = 2;
            double half = lerp(len / 2, 1.6, e);
            if (t >= 70) half = lerp(1.6, 0.5, ease((t - 70) / 10.0));
            double y = mid.y + rise;
            place(s.a, mid.x - ux * half, y, mid.z - uz * half, (float) (t * t * 0.2));
            place(s.b, mid.x + ux * half, y, mid.z + uz * half, (float) (-t * t * 0.2));
            if (t % 2 == 0) {
                lvl.sendParticles(ParticleTypes.ELECTRIC_SPARK, mid.x - ux * half, y + 1, mid.z - uz * half, 4, 1.2, 1.2, 1.2, 0.1);
                lvl.sendParticles(ParticleTypes.ELECTRIC_SPARK, mid.x + ux * half, y + 1, mid.z + uz * half, 4, 1.2, 1.2, 1.2, 0.1);
                lvl.sendParticles(ParticleTypes.END_ROD, mid.x, y + 1.5, mid.z, 2, 0.5 + e * 2, 0.5, 0.5 + e * 2, 0.02);
            }
            if (t == 72) lvl.playSound(null, mid.x, mid.y, mid.z, SoundEvents.GENERIC_EXPLODE, SoundSource.PLAYERS, 1.5f, 1.2f);
        } else if (t == 80) {
            s.a.discard();
            s.b.discard();
            VehicleEntity titan = ModEntities.get(VehicleType.FUSION_TITAN).create(lvl);
            if (titan != null) {
                titan.moveTo(mid.x, mid.y, mid.z, s.player.getYRot() + 180f, 0f);
                lvl.addFreshEntity(titan);
            }
            lvl.sendParticles(ParticleTypes.EXPLOSION_EMITTER, mid.x, mid.y + 3, mid.z, 1, 0, 0, 0, 0);
            lvl.sendParticles(ParticleTypes.END_ROD, mid.x, mid.y + 3, mid.z, 60, 3, 3, 3, 0.2);
            lvl.playSound(null, mid.x, mid.y, mid.z, SoundEvents.WITHER_SPAWN, SoundSource.PLAYERS, 1.2f, 1.3f);
        } else if (t < 90 && t % 2 == 0) {
            lvl.sendParticles(ParticleTypes.ELECTRIC_SPARK, mid.x, mid.y + 3, mid.z, 6, 2.5, 3, 2.5, 0.2);
        }
        return t < DURATION;
    }
}
