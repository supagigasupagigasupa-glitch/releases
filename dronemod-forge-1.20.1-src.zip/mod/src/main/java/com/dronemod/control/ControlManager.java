package com.dronemod.control;

import com.dronemod.DroneMod;
import com.dronemod.entity.VehicleEntity;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import javax.annotation.Nullable;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Server side: latest input of every pilot and which player is remote-piloting which vehicle. */
@Mod.EventBusSubscriber(modid = DroneMod.MODID)
public class ControlManager {
    private static final Map<UUID, ControlState> STATES = new ConcurrentHashMap<>();
    /** player uuid -> entity id of the vehicle they are controlling remotely */
    public static final Map<UUID, Integer> REMOTE = new ConcurrentHashMap<>();

    public static void put(ServerPlayer p, ControlState s) {
        s.tick = p.server.getTickCount();
        STATES.put(p.getUUID(), s);
    }

    public static ControlState get(ServerPlayer p) {
        ControlState s = STATES.get(p.getUUID());
        if (s == null) return new ControlState();
        if (p.server.getTickCount() - s.tick > 4) return s.released();
        return s;
    }

    /** the vehicle this player is riding or remote controlling, if any */
    @Nullable
    public static VehicleEntity vehicleOf(ServerPlayer p) {
        if (p.getVehicle() instanceof VehicleEntity v) return v;
        Integer id = REMOTE.get(p.getUUID());
        if (id != null) {
            Entity e = p.serverLevel().getEntity(id);
            if (e instanceof VehicleEntity v) return v;
        }
        return null;
    }

    @SubscribeEvent
    public static void onLogout(PlayerEvent.PlayerLoggedOutEvent e) {
        UUID id = e.getEntity().getUUID();
        STATES.remove(id);
        Integer vid = REMOTE.remove(id);
        if (vid != null && e.getEntity() instanceof ServerPlayer sp) {
            Entity v = sp.serverLevel().getEntity(vid);
            if (v instanceof VehicleEntity ve) ve.stopRemote(null);
        }
    }
}
