package com.dronemod;

import com.dronemod.network.ModNetwork;
import com.dronemod.registry.ModBlockEntities;
import com.dronemod.registry.ModBlocks;
import com.dronemod.registry.ModEntities;
import com.dronemod.registry.ModItems;
import com.dronemod.registry.ModMenus;
import com.dronemod.registry.ModTabs;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(DroneMod.MODID)
public class DroneMod {
    public static final String MODID = "dronemod";

    public DroneMod() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ModBlocks.BLOCKS.register(bus);
        ModItems.ITEMS.register(bus);
        ModEntities.ENTITIES.register(bus);
        ModBlockEntities.BLOCK_ENTITIES.register(bus);
        ModMenus.MENUS.register(bus);
        ModTabs.TABS.register(bus);
        bus.addListener(this::commonSetup);
    }

    private void commonSetup(final FMLCommonSetupEvent event) {
        event.enqueueWork(ModNetwork::register);
    }
}
