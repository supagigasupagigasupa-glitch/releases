package com.dronemod.registry;

import com.dronemod.DroneMod;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;

public class ModTabs {
    public static final DeferredRegister<CreativeModeTab> TABS = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, DroneMod.MODID);

    public static final RegistryObject<CreativeModeTab> MAIN = TABS.register("main", () -> CreativeModeTab.builder()
            .title(Component.translatable("itemGroup.dronemod"))
            .icon(() -> new ItemStack(ModItems.REMOTE.get()))
            .displayItems((params, out) -> ModItems.ITEMS.getEntries().forEach(r -> out.accept(r.get())))
            .build());
}
