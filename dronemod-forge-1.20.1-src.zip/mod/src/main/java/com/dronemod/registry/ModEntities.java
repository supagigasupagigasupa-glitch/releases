package com.dronemod.registry;

import com.dronemod.DroneMod;
import com.dronemod.entity.VehicleEntity;
import com.dronemod.entity.VehicleType;
import java.util.EnumMap;
import java.util.Map;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, DroneMod.MODID);
    public static final Map<VehicleType, RegistryObject<EntityType<VehicleEntity>>> TYPES = new EnumMap<>(VehicleType.class);

    static {
        for (VehicleType vt : VehicleType.values()) {
            TYPES.put(vt, ENTITIES.register(vt.id, () -> {
                EntityDimensions dims = vt.dimensions(vt.defaultForm);
                return EntityType.Builder.<VehicleEntity>of((type, level) -> new VehicleEntity(type, level, vt), MobCategory.MISC)
                        .sized(dims.width, dims.height)
                        .clientTrackingRange(12)
                        .updateInterval(2)
                        .fireImmune()
                        .build(vt.id);
            }));
        }
    }

    public static EntityType<VehicleEntity> get(VehicleType vt) { return TYPES.get(vt).get(); }
}
