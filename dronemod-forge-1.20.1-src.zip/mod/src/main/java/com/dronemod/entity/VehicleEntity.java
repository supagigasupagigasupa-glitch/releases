package com.dronemod.entity;

import com.dronemod.control.ControlManager;
import com.dronemod.control.ControlState;
import com.dronemod.item.LinkToolItem;
import com.dronemod.item.RemoteItem;
import com.dronemod.network.ModNetwork;
import com.dronemod.network.RemoteModePacket;
import com.dronemod.registry.ModItems;
import java.util.ArrayDeque;
import java.util.Deque;
import java.util.Optional;
import java.util.UUID;
import javax.annotation.Nullable;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MoverType;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.network.PacketDistributor;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.core.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.core.animation.AnimatableManager;
import software.bernie.geckolib.core.animation.AnimationController;
import software.bernie.geckolib.core.animation.AnimationState;
import software.bernie.geckolib.core.animation.RawAnimation;
import software.bernie.geckolib.core.object.PlayState;
import software.bernie.geckolib.util.GeckoLibUtil;

/**
 * One entity class for every drone, car, transformable mecha and the fusion titan.
 * Behaviour is data-driven by {@link VehicleType} and the current {@link Form}.
 * Movement is server authoritative and driven by {@link ControlState} packets, so the same code serves
 * a rider sitting in the vehicle and a pilot remote-controlling it from a computer.
 */
public class VehicleEntity extends PathfinderMob implements GeoEntity {
    private static final EntityDataAccessor<Integer> DATA_FORM = SynchedEntityData.defineId(VehicleEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> DATA_FROM = SynchedEntityData.defineId(VehicleEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> DATA_TO = SynchedEntityData.defineId(VehicleEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Boolean> DATA_ACTIVE = SynchedEntityData.defineId(VehicleEntity.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<Boolean> DATA_MOVING = SynchedEntityData.defineId(VehicleEntity.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<Float> DATA_SPEED = SynchedEntityData.defineId(VehicleEntity.class, EntityDataSerializers.FLOAT);
    private static final EntityDataAccessor<Optional<UUID>> DATA_REMOTE = SynchedEntityData.defineId(VehicleEntity.class, EntityDataSerializers.OPTIONAL_UUID);

    /** 3.0 s - matches the length of the to_* / from_* animations */
    public static final int TRANSFORM_TICKS = 60;

    private final VehicleType vt;
    private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);
    private final Deque<Form> queue = new ArrayDeque<>();
    private int transTicks = 0;
    private int smashCooldown = 0;
    private float carSpeed = 0f;

    public VehicleEntity(EntityType<? extends VehicleEntity> type, Level level, VehicleType vt) {
        super(type, level);
        this.vt = vt;
        this.xpReward = 0;
        this.entityData.set(DATA_FORM, vt.defaultForm.ordinal());
        if (getAttribute(Attributes.MAX_HEALTH) != null) getAttribute(Attributes.MAX_HEALTH).setBaseValue(vt.health);
        setHealth(vt.health);
        setPersistenceRequired();
        setMaxUpStep(vt.scale >= 2 ? 1.6f : 1.1f);
        refreshDimensions();
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 40.0)
                .add(Attributes.MOVEMENT_SPEED, 0.2)
                .add(Attributes.KNOCKBACK_RESISTANCE, 1.0);
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        entityData.define(DATA_FORM, 0);
        entityData.define(DATA_FROM, 0);
        entityData.define(DATA_TO, -1);
        entityData.define(DATA_ACTIVE, false);
        entityData.define(DATA_MOVING, false);
        entityData.define(DATA_SPEED, 0f);
        entityData.define(DATA_REMOTE, Optional.empty());
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putInt("Form", getForm().ordinal());
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        if (tag.contains("Form")) entityData.set(DATA_FORM, tag.getInt("Form"));
        refreshDimensions();
    }

    // ------------------------------------------------------------------ simple accessors
    public VehicleType getVehicleType() { return vt; }
    public Form getForm() { return Form.byOrdinal(entityData.get(DATA_FORM)); }
    public boolean isTransitioning() { return entityData.get(DATA_TO) >= 0; }
    public Form transitionFrom() { return Form.byOrdinal(entityData.get(DATA_FROM)); }
    public Form transitionTo() { return Form.byOrdinal(entityData.get(DATA_TO)); }
    public boolean isActive() { return entityData.get(DATA_ACTIVE); }
    public boolean isMovingFlag() { return entityData.get(DATA_MOVING); }
    public float getSpeedBlocksPerSecond() { return entityData.get(DATA_SPEED) * 20f; }
    public boolean isRemoteControlled() { return entityData.get(DATA_REMOTE).isPresent(); }

    @Override
    public void onSyncedDataUpdated(EntityDataAccessor<?> key) {
        super.onSyncedDataUpdated(key);
        if (key == DATA_FORM) refreshDimensions();
    }

    @Override
    public EntityDimensions getDimensions(Pose pose) {
        return vt == null ? super.getDimensions(pose) : vt.dimensions(getForm());
    }

    @Override
    protected float getStandingEyeHeight(Pose pose, EntityDimensions dims) {
        return vt == null ? super.getStandingEyeHeight(pose, dims) : vt.eyeHeight(getForm());
    }

    @Override
    public double getPassengersRidingOffset() {
        return vt == null ? super.getPassengersRidingOffset() : vt.seatHeight(getForm());
    }

    @Override
    public AABB getBoundingBoxForCulling() {
        return vt == null ? super.getBoundingBoxForCulling() : getBoundingBox().inflate(vt.scale * 3.0);
    }

    @Override protected void registerGoals() { }
    @Override public boolean removeWhenFarAway(double distance) { return false; }
    @Override public boolean isPushable() { return false; }
    @Override public boolean causeFallDamage(float distance, float multiplier, DamageSource source) { return false; }

    @Override
    protected boolean canAddPassenger(Entity passenger) {
        return getPassengers().isEmpty() && passenger instanceof Player && !isTransitioning();
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        if (source.getEntity() != null && hasPassenger(source.getEntity())) return false;
        return super.hurt(source, amount);
    }

    @Override
    public void die(DamageSource source) {
        super.die(source);
        if (!level().isClientSide) {
            stopRemote(null);
            spawnAtLocation(new ItemStack(ModItems.dropFor(vt)));
        }
    }

    // ------------------------------------------------------------------ interaction
    @Override
    protected InteractionResult mobInteract(Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (stack.getItem() instanceof RemoteItem) {
            if (level().isClientSide) return InteractionResult.SUCCESS;
            if (player.isShiftKeyDown()) toggleRemote((ServerPlayer) player);
            else if (getPassengers().isEmpty() && !player.isPassenger() && !isRemoteControlled()) player.startRiding(this);
            else ((ServerPlayer) player).displayClientMessage(Component.translatable("message.dronemod.in_use"), true);
            return InteractionResult.CONSUME;
        }
        if (stack.getItem() instanceof LinkToolItem) {
            if (!level().isClientSide) LinkToolItem.select(player, stack, this);
            return InteractionResult.sidedSuccess(level().isClientSide);
        }
        if (stack.is(Items.IRON_INGOT) && getHealth() < getMaxHealth()) {
            if (!level().isClientSide) {
                heal(10f);
                if (!player.getAbilities().instabuild) stack.shrink(1);
                playSound(SoundEvents.ANVIL_USE, 0.6f, 1.5f);
            }
            return InteractionResult.sidedSuccess(level().isClientSide);
        }
        return InteractionResult.PASS;
    }

    // ------------------------------------------------------------------ remote piloting
    private void toggleRemote(ServerPlayer sp) {
        Optional<UUID> cur = entityData.get(DATA_REMOTE);
        if (cur.isPresent() && cur.get().equals(sp.getUUID())) { stopRemote(sp); return; }
        if (cur.isPresent() || !getPassengers().isEmpty()) {
            sp.displayClientMessage(Component.translatable("message.dronemod.in_use"), true);
            return;
        }
        startRemote(sp);
    }

    public boolean startRemote(ServerPlayer sp) {
        if (isRemoteControlled() || !getPassengers().isEmpty()) return false;
        entityData.set(DATA_REMOTE, Optional.of(sp.getUUID()));
        ControlManager.REMOTE.put(sp.getUUID(), getId());
        ModNetwork.CH.send(PacketDistributor.PLAYER.with(() -> sp), new RemoteModePacket(true, getId()));
        return true;
    }

    public void stopRemote(@Nullable ServerPlayer sp) {
        Optional<UUID> cur = entityData.get(DATA_REMOTE);
        if (cur.isEmpty()) return;
        entityData.set(DATA_REMOTE, Optional.empty());
        ControlManager.REMOTE.remove(cur.get());
        ServerPlayer target = sp;
        if (target == null && level() instanceof ServerLevel sl) target = sl.getServer().getPlayerList().getPlayer(cur.get());
        if (target != null) {
            final ServerPlayer t = target;
            ModNetwork.CH.send(PacketDistributor.PLAYER.with(() -> t), new RemoteModePacket(false, getId()));
        }
    }

    @Nullable
    private ServerPlayer pilot() {
        if (!(level() instanceof ServerLevel sl)) return null;
        Entity p = getFirstPassenger();
        if (p instanceof ServerPlayer sp) return sp;
        Optional<UUID> r = entityData.get(DATA_REMOTE);
        return r.isPresent() ? sl.getServer().getPlayerList().getPlayer(r.get()) : null;
    }

    // ------------------------------------------------------------------ transformation
    /** @return true if a transformation was started */
    public boolean requestForm(Form target) {
        if (level().isClientSide || isTransitioning() || !vt.allows(target) || target == getForm()) return false;
        queue.clear();
        Form cur = getForm();
        if (vt.multiForm()) {
            if (target == Form.MECHA) queue.add(Form.MECHA);
            else if (cur == Form.MECHA) queue.add(target);
            else { queue.add(Form.MECHA); queue.add(target); }   // always change shape through the mecha
        } else {
            queue.add(target);
        }
        startNextStep();
        return true;
    }

    /** two-form vehicles: flip between the vehicle and the mecha */
    public boolean toggleForm() {
        return requestForm(getForm() == Form.MECHA ? (vt.multiForm() ? Form.CAR : Form.VEHICLE) : Form.MECHA);
    }

    private void startNextStep() {
        Form next = queue.poll();
        if (next == null) { entityData.set(DATA_TO, -1); return; }
        entityData.set(DATA_FROM, getForm().ordinal());
        entityData.set(DATA_TO, next.ordinal());
        transTicks = 0;
        level().playSound(null, blockPosition(), SoundEvents.PISTON_EXTEND, SoundSource.NEUTRAL, 1.2f, 0.6f);
    }

    private void tickTransition() {
        transTicks++;
        if (level() instanceof ServerLevel sl && transTicks % 3 == 0) {
            sl.sendParticles(ParticleTypes.ELECTRIC_SPARK, getX(), getY() + getBbHeight() * 0.5, getZ(), 6, getBbWidth() * 0.5, getBbHeight() * 0.3, getBbWidth() * 0.5, 0.15);
            if (transTicks == 30) sl.sendParticles(ParticleTypes.POOF, getX(), getY() + getBbHeight() * 0.5, getZ(), 18, getBbWidth() * 0.5, getBbHeight() * 0.3, getBbWidth() * 0.5, 0.05);
        }
        if (transTicks == 30) level().playSound(null, blockPosition(), SoundEvents.IRON_GOLEM_REPAIR, SoundSource.NEUTRAL, 1.0f, 0.8f);
        if (transTicks >= TRANSFORM_TICKS) {
            Form to = transitionTo();
            entityData.set(DATA_FORM, to.ordinal());
            entityData.set(DATA_TO, -1);
            refreshDimensions();
            level().playSound(null, blockPosition(), SoundEvents.BEACON_POWER_SELECT, SoundSource.NEUTRAL, 1.0f, 1.2f);
            startNextStep();
        }
    }

    // ------------------------------------------------------------------ smash attack (walking forms)
    public void smash(ServerPlayer who) {
        if (level().isClientSide || smashCooldown > 0 || isTransitioning() || vt.mode(getForm()) != Mode.WALK) return;
        smashCooldown = 30;
        float r = 2.5f * vt.scale + 1.5f;
        ServerLevel sl = (ServerLevel) level();
        for (LivingEntity e : sl.getEntitiesOfClass(LivingEntity.class, getBoundingBox().inflate(r, 1.0, r),
                x -> x != this && x != who && !(x instanceof VehicleEntity))) {
            e.hurt(damageSources().playerAttack(who), 8f + vt.scale * 2f);
            Vec3 d = e.position().subtract(position());
            Vec3 n = new Vec3(d.x, 0, d.z).normalize();
            e.push(n.x * 1.1, 0.5, n.z * 1.1);
        }
        sl.sendParticles(ParticleTypes.EXPLOSION, getX(), getY() + 0.2, getZ(), 3, r * 0.3, 0.1, r * 0.3, 0.0);
        sl.sendParticles(ParticleTypes.POOF, getX(), getY() + 0.2, getZ(), 25, r * 0.4, 0.1, r * 0.4, 0.05);
        sl.playSound(null, blockPosition(), SoundEvents.GENERIC_EXPLODE, SoundSource.NEUTRAL, 1.2f, 0.7f);
    }

    // ------------------------------------------------------------------ ticking
    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide) return;
        if (smashCooldown > 0) smashCooldown--;
        ServerPlayer p = pilot();
        boolean active = p != null;
        if (entityData.get(DATA_ACTIVE) != active) entityData.set(DATA_ACTIVE, active);
        Optional<UUID> r = entityData.get(DATA_REMOTE);
        if (r.isPresent() && level() instanceof ServerLevel sl) {
            ServerPlayer rp = sl.getServer().getPlayerList().getPlayer(r.get());
            if (rp == null || rp.isRemoved() || rp.level() != level() || !rp.isAlive()) stopRemote(rp);
        }
        if (isTransitioning()) tickTransition();
    }

    private boolean grounded() { return this.onGround(); }

    private void faceYaw(float target, float maxTurn) {
        float y = Mth.approachDegrees(getYRot(), target, maxTurn);
        setYRot(y);
        this.yBodyRot = y;
        this.yHeadRot = y;
    }

    @Override
    public void travel(Vec3 ignored) {
        if (level().isClientSide) return;
        ServerPlayer p = pilot();
        ControlState cs = p == null ? new ControlState() : ControlManager.get(p);
        Form form = getForm();
        Mode mode = vt.mode(form);
        boolean transitioning = isTransitioning();
        boolean pilotOk = p != null && !transitioning;
        float maxSp = vt.speed(form);
        Vec3 v = getDeltaMovement();
        double vx = v.x, vy = v.y, vz = v.z;

        boolean wantNoGravity = pilotOk && (mode == Mode.HOVER || mode == Mode.PLANE);
        if (isNoGravity() != wantNoGravity) setNoGravity(wantNoGravity);

        if (transitioning) {
            vx *= 0.5; vz *= 0.5;
            vy = grounded() ? 0 : (vy - 0.08) * 0.98;
        } else {
            switch (mode) {
                case WALK: {
                    if (pilotOk) {
                        Vec3 fwd = Vec3.directionFromRotation(0, cs.yaw);
                        Vec3 left = new Vec3(fwd.z, 0, -fwd.x);
                        Vec3 wish = fwd.scale(cs.forward).add(left.scale(cs.strafe));
                        double len = wish.length();
                        if (len > 1) wish = wish.scale(1 / len);
                        double sp = maxSp * (cs.boost ? 1.45 : 1.0);
                        vx += (wish.x * sp - vx) * 0.22;
                        vz += (wish.z * sp - vz) * 0.22;
                        faceYaw(cs.yaw, 18f);
                    } else { vx *= 0.6; vz *= 0.6; }
                    if (pilotOk && cs.up && grounded()) vy = 0.5 + vt.scale * 0.03;
                    else vy = grounded() ? 0 : (vy - 0.08) * 0.98;
                    break;
                }
                case GROUND_CAR: {
                    if (pilotOk) {
                        double boostMul = cs.boost ? 1.45 : 1.0;
                        carSpeed += cs.forward * 0.035 * boostMul;
                        if (cs.forward == 0) carSpeed *= 0.95f;
                        if (cs.down) carSpeed *= 0.8f;
                        carSpeed = (float) Mth.clamp(carSpeed, -maxSp * 0.45, maxSp * boostMul);
                        if (Math.abs(carSpeed) > 0.02f) {
                            float steer = cs.strafe * 4.5f * (float) Mth.clamp(Math.abs(carSpeed) / maxSp, 0.3, 1.0) * Math.signum(carSpeed);
                            faceYaw(getYRot() - steer, 30f);
                        }
                    } else carSpeed *= 0.92f;
                    Vec3 heading = Vec3.directionFromRotation(0, getYRot());
                    vx = heading.x * carSpeed;
                    vz = heading.z * carSpeed;
                    if (pilotOk && cs.up && grounded()) vy = 0.38;
                    else vy = grounded() ? 0 : (vy - 0.08) * 0.98;
                    if (Math.abs(carSpeed) > 0.3) roadkill(Math.abs(carSpeed));
                    if (pilotOk && cs.boost && Math.abs(carSpeed) > 0.4 && level() instanceof ServerLevel sl && tickCount % 2 == 0) {
                        sl.sendParticles(ParticleTypes.FLAME, getX() - heading.x * getBbWidth(), getY() + 0.3, getZ() - heading.z * getBbWidth(), 2, 0.1, 0.05, 0.1, 0.02);
                    }
                    break;
                }
                case HOVER: {
                    if (pilotOk) {
                        Vec3 look = Vec3.directionFromRotation(cs.pitch, cs.yaw);
                        Vec3 flat = Vec3.directionFromRotation(0, cs.yaw);
                        Vec3 left = new Vec3(flat.z, 0, -flat.x);
                        double sp = maxSp * (cs.boost ? 1.5 : 1.0);
                        double vert = ((cs.up ? 1 : 0) - (cs.down ? 1 : 0)) * sp * 0.7;
                        Vec3 target = look.scale(cs.forward * sp).add(left.scale(cs.strafe * sp * 0.8)).add(0, vert, 0);
                        vx += (target.x - vx) * 0.12;
                        vy += (target.y - vy) * 0.12;
                        vz += (target.z - vz) * 0.12;
                        faceYaw(cs.yaw, 14f);
                    } else {
                        vx *= 0.8; vz *= 0.8;
                        vy = grounded() ? 0 : (vy - 0.06) * 0.98;
                    }
                    break;
                }
                default: { // PLANE
                    if (pilotOk) {
                        double thrust = cs.forward > 0.3 ? 1.0 : cs.forward < -0.3 ? 0.2 : 0.55;
                        double sp = maxSp * thrust * (cs.boost ? 1.4 : 1.0);
                        Vec3 look = Vec3.directionFromRotation(Mth.clamp(cs.pitch, -60f, 60f), cs.yaw);
                        Vec3 flat = Vec3.directionFromRotation(0, cs.yaw);
                        Vec3 left = new Vec3(flat.z, 0, -flat.x);
                        double vert = ((cs.up ? 1 : 0) - (cs.down ? 1 : 0)) * 0.2;
                        Vec3 target = look.scale(sp).add(left.scale(cs.strafe * 0.15)).add(0, vert, 0);
                        vx += (target.x - vx) * 0.08;
                        vy += (target.y - vy) * 0.08;
                        vz += (target.z - vz) * 0.08;
                        faceYaw(cs.yaw, 8f);
                    } else {
                        vx *= 0.9; vz *= 0.9;
                        vy = grounded() ? 0 : (vy - 0.06) * 0.98;
                    }
                    break;
                }
            }
        }

        setDeltaMovement(vx, vy, vz);
        move(MoverType.SELF, getDeltaMovement());

        if (horizontalCollision) {
            carSpeed *= 0.5f;
            if (mode == Mode.PLANE && getDeltaMovement().horizontalDistance() < 0.2 && pilotOk && cs.forward >= 0 && tickCount % 10 == 0) hurt(damageSources().flyIntoWall(), 2f);
        }

        double hs = getDeltaMovement().horizontalDistance();
        boolean moving = hs > 0.03 || (mode == Mode.HOVER && getDeltaMovement().length() > 0.05);
        if (entityData.get(DATA_MOVING) != moving) entityData.set(DATA_MOVING, moving);
        float sp = (float) getDeltaMovement().length();
        if (Math.abs(entityData.get(DATA_SPEED) - sp) > 0.01f) entityData.set(DATA_SPEED, sp);
    }

    private void roadkill(double speed) {
        if (tickCount % 4 != 0) return;
        for (LivingEntity e : level().getEntitiesOfClass(LivingEntity.class, getBoundingBox().inflate(0.4, 0.1, 0.4),
                x -> x != this && !hasPassenger(x) && !(x instanceof VehicleEntity))) {
            e.hurt(damageSources().mobAttack(this), (float) (speed * 14));
            Vec3 d = e.position().subtract(position());
            Vec3 n = new Vec3(d.x, 0, d.z).normalize();
            e.push(n.x * speed * 1.2, 0.25, n.z * speed * 1.2);
        }
    }

    // ------------------------------------------------------------------ GeckoLib animation
    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        controllers.add(new AnimationController<>(this, "main", 0, this::mainController));
        controllers.add(new AnimationController<>(this, "extra", 2, this::extraController));
        controllers.add(new AnimationController<>(this, "motion", 0, this::motionController));
    }

    @Override
    public AnimatableInstanceCache getAnimatableInstanceCache() { return cache; }

    private String transitionAnim(Form from, Form to) {
        if (vt.multiForm()) return to == Form.MECHA ? "from_" + from.id : "to_" + to.id;
        return to == Form.MECHA ? "to_mecha" : "to_vehicle";
    }

    @Nullable
    private String poseAnim(Form f) {
        if (vt == VehicleType.DRONE || vt == VehicleType.CAR || vt == VehicleType.FUSION_TITAN) return null;
        return "pose_" + f.id;
    }

    private PlayState mainController(AnimationState<VehicleEntity> state) {
        if (isTransitioning()) {
            return state.setAndContinue(RawAnimation.begin().thenPlayAndHold(transitionAnim(transitionFrom(), transitionTo())));
        }
        String pose = poseAnim(getForm());
        if (pose == null) return PlayState.STOP;
        return state.setAndContinue(RawAnimation.begin().thenLoop(pose));
    }

    private PlayState extraController(AnimationState<VehicleEntity> state) {
        if (isTransitioning()) return PlayState.STOP;
        Form f = getForm();
        boolean mv = isMovingFlag();
        String anim = null;
        switch (vt) {
            case MINI_TRANSFORMER:
            case GIANT_DRONE:
            case MINI_CAR:
            case GIANT_CAR:
                if (f == Form.MECHA) anim = mv ? "walk" : "idle";
                break;
            case RED_SILVER:
                if (f == Form.MECHA) anim = mv ? "walk" : "idle";
                else if (f == Form.DINO) anim = mv ? "dino_walk" : "dino_idle";
                else if (f == Form.PLANE) anim = "plane_idle";
                break;
            case FUSION_TITAN:
                anim = mv ? "walk" : "idle";
                break;
            default:
                break;
        }
        if (anim == null) return PlayState.STOP;
        return state.setAndContinue(RawAnimation.begin().thenLoop(anim));
    }

    private PlayState motionController(AnimationState<VehicleEntity> state) {
        String anim = null;
        switch (vt) {
            case DRONE: if (isActive()) anim = "spin"; break;
            case CAR: if (isMovingFlag()) anim = "wheel_spin"; break;
            case MINI_TRANSFORMER:
            case GIANT_DRONE: if (isActive()) anim = "spin_all"; break;
            case MINI_CAR:
            case GIANT_CAR: if (isMovingFlag()) anim = "wheel_spin_all"; break;
            case RED_SILVER:
                if (getForm() == Form.CAR && isMovingFlag()) anim = "wheel_spin";
                else if (getForm() == Form.HELI && isActive()) anim = "heli_rotors";
                break;
            case FUSION_TITAN: if (isActive()) anim = "spin"; break;
            default: break;
        }
        if (anim == null) return PlayState.STOP;
        return state.setAndContinue(RawAnimation.begin().thenLoop(anim));
    }
}
