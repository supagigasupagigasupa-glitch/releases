package com.dronemod.entity;

/** How a form moves. */
public enum Mode { GROUND_CAR, WALK, HOVER, PLANE }
