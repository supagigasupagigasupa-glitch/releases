package com.dronemod.network;

import com.dronemod.control.ControlManager;
import com.dronemod.control.ControlState;
import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

/** client -> server: current inputs of the pilot (sent every tick while piloting) */
public class ControlPacket {
    private final ControlState s;

    public ControlPacket(ControlState s) { this.s = s; }

    public static void encode(ControlPacket m, FriendlyByteBuf buf) {
        buf.writeFloat(m.s.forward).writeFloat(m.s.strafe).writeFloat(m.s.yaw).writeFloat(m.s.pitch);
        int flags = (m.s.up ? 1 : 0) | (m.s.down ? 2 : 0) | (m.s.boost ? 4 : 0);
        buf.writeByte(flags);
    }

    public static ControlPacket decode(FriendlyByteBuf buf) {
        ControlState s = new ControlState();
        s.forward = buf.readFloat(); s.strafe = buf.readFloat(); s.yaw = buf.readFloat(); s.pitch = buf.readFloat();
        int f = buf.readByte();
        s.up = (f & 1) != 0; s.down = (f & 2) != 0; s.boost = (f & 4) != 0;
        return new ControlPacket(s);
    }

    public static void handle(ControlPacket m, Supplier<NetworkEvent.Context> ctx) {
        NetworkEvent.Context c = ctx.get();
        c.enqueueWork(() -> {
            ServerPlayer p = c.getSender();
            if (p != null) ControlManager.put(p, m.s);
        });
        c.setPacketHandled(true);
    }
}
