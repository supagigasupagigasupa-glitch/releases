package com.dronemod.network;

import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

/** server -> client: start the 5 second cinematic around the fusion point */
public class FusionPacket {
    private final double x, y, z, theta0;

    public FusionPacket(double x, double y, double z, double theta0) { this.x = x; this.y = y; this.z = z; this.theta0 = theta0; }

    public static void encode(FusionPacket m, FriendlyByteBuf buf) { buf.writeDouble(m.x).writeDouble(m.y).writeDouble(m.z).writeDouble(m.theta0); }

    public static FusionPacket decode(FriendlyByteBuf buf) { return new FusionPacket(buf.readDouble(), buf.readDouble(), buf.readDouble(), buf.readDouble()); }

    public static void handle(FusionPacket m, Supplier<NetworkEvent.Context> ctx) {
        NetworkEvent.Context c = ctx.get();
        c.enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> com.dronemod.client.ClientHooks.fusion(m.x, m.y, m.z, m.theta0)));
        c.setPacketHandled(true);
    }
}
